hey, you yes YOU

run the "run OCR" first to create the folder "Scan Image" and "Result"
just copy and paste it to "Scan Image"